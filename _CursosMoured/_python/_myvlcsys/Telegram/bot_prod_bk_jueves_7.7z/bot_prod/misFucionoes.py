
def f_saludo():
    return "Hola desde funcion"


def consulta_bd():
    return "consulta bd"

