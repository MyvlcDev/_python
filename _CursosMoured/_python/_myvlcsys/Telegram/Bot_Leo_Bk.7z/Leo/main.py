import telebot

# Conexión con nuetro BOT
TOKEN = "1478529541:AAH4BlDnjVB7tui30G7w_4MgKLU52scl_ww"
bot = telebot.TeleBot(TOKEN)


# Creación de comando simples como '/start' y '/help'
@bot.message_handler(commands=["start"])
def send_welcome(message):
    bot.reply_to(message, "Hola mundo!")


@bot.message_handler(commands=["help"])
def send_help(message):
    bot.reply_to(message, "Puedes interactuar con este bot a través de /start y /help")

@bot.message_handler(func=lambda m: True)
def echo_all(message):
    bot.reply_to(message, message.text)

if __name__ == "__main__":
    bot.polling(none_stop=True)
